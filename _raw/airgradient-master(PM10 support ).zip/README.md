# AirGradient Library
ESP8266 (Wemos D1 Mini) library for the AirGradient kit

This is a fork of [https://github.com/airgradienthq/arduino](https://github.com/airgradienthq/arduino), see there for more details and to check out the great work the AirGradient team is doing!

# Changes
I made following changes in my fork:
- Added support for PM1 and PM10
- Minor code fixes